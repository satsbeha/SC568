console.log( Boolean(null))

localStorage.setItem("token",null)