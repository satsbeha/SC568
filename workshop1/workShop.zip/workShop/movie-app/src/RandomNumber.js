 export default function RandomNumber(){
    return Math.floor(10000 + Math.random() * 900)
}
